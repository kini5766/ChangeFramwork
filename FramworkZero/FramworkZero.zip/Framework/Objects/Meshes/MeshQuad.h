#pragma once

class MeshQuad : public MeshData
{
public:
	MeshQuad();
	~MeshQuad();
};
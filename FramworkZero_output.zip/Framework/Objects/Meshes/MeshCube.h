#pragma once

class MeshCube : public MeshData
{
public:
	MeshCube();
	~MeshCube();
};
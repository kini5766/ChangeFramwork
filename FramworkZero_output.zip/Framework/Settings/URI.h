#pragma once

namespace URI
{
	// ���� Libraries = L"../../_Libraries"
	const wstring Shaders = L"../_Shaders/";
	const wstring Textures = L"../../_Resource/Textures/";
	const wstring Models = L"../../_Resource/Models/";
	const wstring Assets = L"../../_Resource/Assets/";
	const wstring Scenes = L"../../_Resource/Scenes/";
}

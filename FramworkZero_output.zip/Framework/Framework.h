#pragma once

#include <Windows.h>
#include <assert.h>

//STL
#include <string>
#include <vector>
#include <list>
#include <bitset>
#include <map>
#include <unordered_map>
#include <functional>
#include <iterator>
#include <thread>
#include <mutex>
#include <queue>
using namespace std;

//Direct3D
#include <dxgi1_2.h>
#include <d3dcommon.h>
#include <d3dcompiler.h>
#include <d3d11shader.h>
#include <d3d11.h>
#include <d3dx10math.h>
#include <d3dx11async.h>
#include <d3dx11effect.h>

#pragma comment(lib, "dxgi.lib")
#pragma comment(lib, "d3d11.lib")
#pragma comment(lib, "d3dx9.lib")
#pragma comment(lib, "d3dx10.lib")
#pragma comment(lib, "d3dx11.lib")
#pragma comment(lib, "d3dcompiler.lib")
#pragma comment(lib, "dxguid.lib")
#pragma comment(lib, "Effects11d.lib")

//ImGui (������)
#include <ImGui/imgui.h>
#include <ImGui/imgui_impl_dx11.h>
#include <ImGui/imgui_impl_win32.h>
#include <ImGui/ImGuizmo.h>
#pragma comment(lib, "ImGui/imgui.lib")

// ImGui (DockSpace)
//#include <ImGui/imgui.h>
//#include <ImGui/backends/imgui_impl_dx11.h>
//#include <ImGui/backends/imgui_impl_win32.h>
////#pragma comment(lib, "Debug/imgui.lib");  // ���� �߰��ϸ� lib�˾Ƽ� ����
//#include <ImGuizmo/ImGuizmo.h>


//DirectXTex
#include <DirectXTex.h>
#pragma comment(lib, "directxtex.lib")

#define Check(hr) { assert(SUCCEEDED(hr)); }
#define Super __super

#define SafeRelease(p){ if(p){ (p)->Release(); (p) = NULL; } }
#define SafeDelete(p){ if(p){ delete (p); (p) = NULL; } }
#define SafeDeleteArray(p){ if(p){ delete [] (p); (p) = NULL; } }

typedef D3DXVECTOR2 Vector2;
typedef D3DXVECTOR3 Vector3;
typedef D3DXVECTOR4 Vector4;
typedef D3DXCOLOR Color;
typedef D3DXMATRIX Matrix;
typedef D3DXQUATERNION Quaternion;
typedef D3DXPLANE Plane;


// Settings
// ���� �� ������ ����

#include "Settings/URI.h"
#include "Settings/Layer.h"
#include "Settings/ShaderEffectName.h"


// Systems
// ������, d3d, imgui ����

#include "Systems/D3D.h"
#include "Systems/Gui.h"


// Tools
// �ʿ��� �� ���� ���� Ŭ������ (Ư¡ : Rendering���� Ŭ������ ������� ����)

#include "Tools/MainLogic/Keyboard.h"
#include "Tools/MainLogic/Mouse.h"
#include "Tools/MainLogic/Time.h"
//#include "Tools/MainLogic/GameLogic.h"

#include "Tools/Math.h"
#include "Tools/WinDesc.h"
#include "Tools/Transform.h"

#include "Tools/Texture/Texture.h"
#include "Tools/Texture/Texture2D.h"
#include "Tools/Texture/DepthStencil.h"
#include "Tools/Texture/RenderTarget.h"

#include "Tools/Viewer/Viewport.h"
#include "Tools/Viewer/Projection.h"
#include "Tools/Viewer/Perspective.h"
#include "Tools/Viewer/Orthographic.h"
#include "Tools/Viewer/Camera.h"
#include "Tools/Viewer/Freedom.h"

#include "Tools/Lighting/LightingDesc.h"
#include "Tools/Lighting/DirectionalLight.h"
#include "Tools/Lighting/PointLight.h"
#include "Tools/Lighting/SpotLight.h"
#include "Tools/Lighting/BurntLight.h"
#include "Tools/Lighting/Lighting.h"

#include "Tools/Animation/ClipTimer.h"
#include "Tools/Animation/Animator.h"

#include "Tools/Collider/Ray.h"
#include "Tools/Collider/Collider.h"
#include "Tools/Collider/ColliderBox.h"
#include "Tools/Collider/CollisionManager.h"
#include "Tools/Collider/SendBox.h"
#include "Tools/Collider/ReceiveBox.h"


//Rendering
// IASet�ϰų�, Shader�� �� �Ѱ��ִ� Ŭ������

#include "Rendering/Shader.h"
#include "Rendering/Buffers/Buffers.h"

#include "Rendering/CBufferVariables/Context.h"
#include "Rendering/CBufferVariables/ShaderSetter.h"
#include "Rendering/CBufferVariables/Material.h"
#include "Rendering/CBufferVariables/PerFrame.h"


// Utilities
// ������

#include "Utilities/String.h"
#include "Utilities/Path.h"


// Objects
// RenderingŬ������ �̿��ؼ� ��ü�� �׸��� Ŭ����

#include "Objects/Meshes/MeshData.h"
#include "Objects/Meshes/MeshQuad.h"
#include "Objects/Meshes/MeshPlane.h"
#include "Objects/Meshes/MeshCube.h"
#include "Objects/Meshes/MeshCylinder.h"
#include "Objects/Meshes/MeshSphere.h"
#include "Objects/Meshes/MeshRenderer.h"
#include "Objects/Meshes/MeshInstancing.h"
#include "Objects/Meshes/SkinnedMeshRenderer.h"

#include "Objects/Model/ModelData.h"
#include "Objects/Model/ModelAnimationDesc.h"
#include "Objects/Model/ModelSkinnedInstancing.h"

#include "Objects/Render2D.h"
#include "Objects/PostEffect.h"
#include "Objects/CubeSky.h"
#include "Objects/Billboard.h"


// Debugger
// ����׿� Ŭ������

#include "Debugger/DebugLog.h"
#include "Debugger/DebugLine.h"
#include "Debugger/DebugBox.h"
#include "Debugger/Gizmo.h"


#include "stdafx.h"
#include "EnemyInstance.h"

#include "Character/Paladin.h"
#include "Tools/Viewer/IFocus.h"

#include "Component/HPSystem.h"
#include "Component/RotateSystem.h"
#include "Enemy/EnemyDesc.h"

EnemyInstance::EnemyInstance(const EnemyInstanceDesc* desc)
	: player(desc->Player), transform(desc->Transform), animator(desc->Animator), attack(desc->Attack)
	, runSpeed(desc->Desc->RunSpeed), walkSpeed(desc->Desc->WalkSpeed), turnSpeed(desc->Desc->TurnSpeed)
	, detectionRange(desc->Desc->DetectionRange), attackRange(desc->Desc->AttackRange)
	, patrolPoints(*desc->PatrolPoints)
{
	hp = new HPSystem(desc->Desc->HP);
	hp->GetHpbar()->SetParent(transform);
	hp->GetHpbar()->Position(0, 180.0f, 0);

	hp->GetHurtbox()->GetTransform()->Scale(2.25f, 5.40f, 2.25f);
	hp->GetHurtbox()->GetTransform()->SetParent(transform);
	//hp->GetHurtbox()->GetTransform()->Scale(75.0f, 180.0f, 75.0f);
	hp->GetHurtbox()->GetTransform()->Position(0.0f, 90.0f, 0.0f);
	hp->GetHurtbox()->GetTransform()->Rotation(0.0f, 0.0f, 0.0f);
	hp->GetHurtbox()->SetLayer(
		COLLIDER_LAYER_ENEMY |
		COLLIDER_LAYER_HITBOX
	);
	hp->GetHurtbox()->Tag(L"Enemy");
	hp->AddReceiveTag(L"PlayerAttack");
	hp->SetFuncDamage(bind(&EnemyInstance::OnDamage, this));

	animator->SetFuncNext(
		bind(&EnemyInstance::OnNextAnimation, this, placeholders::_1)
	);

	ratate = new RotateSystem();
}

EnemyInstance::~EnemyInstance()
{
	SafeDelete(ratate);
	SafeDelete(hp);
	SafeDelete(animator);
}

void EnemyInstance::Update()
{
	if (bLost)
		return;

	UpdateState();
	animator->Update();
	hp->Update();
}

void EnemyInstance::Render()
{
	if (bLost)
		return;

	hp->Render();
}

void EnemyInstance::UpdateState()
{
	if (hp->HP() <= 0.0f)
	{
		if (currAction != 6)
		{
			animator->Play(6);
			currAction = 6;
		}
		return;
	}

	if (reactRunTime > 0.0f)
	{
		reactRunTime -= Time::Delta();
		if (currAction != 5)
		{
			animator->Play(5);
			currAction = 5;
		}
		return;
	}

	if (attack->IsAttacking())
		return;

	Vector3 position;
	transform->Position(&position);

	Vector3 focus;
	player->Focus(&focus);
	Vector3 dest = focus - position;
	float lengthSq = D3DXVec3LengthSq(&dest);

	if (lengthSq <= attackRange * attackRange)
		NextAtteck(nextAction, dest);
	else if (lengthSq <= detectionRange * detectionRange)
		NextRun(nextAction, dest);
	else
		NextIdle(nextAction);

	if (currAction != nextAction)
	{
		animator->Play(nextAction);
		currAction = nextAction;
	}
}

// �ִϸ��̼� �̺�Ʈ
void EnemyInstance::OnNextAnimation(UINT next)
{
	if (currAction == 3)
		nextAction = next;

	if (currAction == 4)
	{
		if (attack->IsAttacking() == false)
		{
			nextAction = next;
		}
	}


	if (next == 6 && bFall)
	{
		bLost = true;
		transform->Scale(0.0f, 0.0f, 0.0f);
	}

	if (next == 6)
	{
		bFall = true;
	}
}

void EnemyInstance::OnDamage()
{
	if (hp->HP() <= 0.0f)
	{
		attack->Stop();
	}
	else if (reactRunTime <= 0.0f && currAction != 4)
	{
		reactRunTime = reactTime;
	}
}

void EnemyInstance::NextAtteck(UINT & next, const Vector3 & dest)
{
	if (currAction == 4)
		return;

	if (next == 4)
		return;

	float speedDelta = runSpeed * Time::Delta();

	Vector3 dest2 = dest;
	dest2.y = 0.0f;
	D3DXVec3Normalize(&dest2, &dest2);

	// ȸ��
	ratate->SetTarget(dest2);
	Quaternion q;
	transform->Rotation(&q);
	float rad;
	q = ratate->GetRotation(q, -transform->Forward(), speedDelta * turnSpeed, &rad);

	if (rad <= 0.07f)
		next = 0;
	else
	{
		next = 2;
		transform->Rotation(q);
	}

	if (attack->IsAttackAble())
	{
		attack->Play();
		next = 4;
	}
}

void EnemyInstance::NextRun(UINT & next, const Vector3 & dest)
{
	if (next != 3 && next != 2)
	{
		// ���� ���� �� �ٷ� �޸���
		if (bWariness)
		{
			next = 2;
		}
		// ó�� ������ ����
		else 
		{
			//UINT size = patrolPoints.size();
			//currPatrol = (currPatrol + size - 1) % size;
			next = 3;
		}

		bWariness = true;
	}
	else
	//if ((next == 3) || (next == 2))
	{
		float speedDelta = runSpeed * Time::Delta();

		Vector3 dest2 = dest;
		dest2.y = 0.0f;
		D3DXVec3Normalize(&dest2, &dest2);

		// ȸ��
		ratate->SetTarget(dest2);
		Quaternion q;
		transform->Rotation(&q);
		q = ratate->GetRotation(q, -transform->Forward(), speedDelta * turnSpeed);
		transform->Rotation(q);

		if (next == 2)
		{
			// �̵�
			Vector3 position;
			transform->Position(&position);
			position += -transform->Forward() * speedDelta;
			transform->Position(position);
		}
	}
}

void EnemyInstance::NextIdle(UINT & next)
{
	if (next == 3)
	{
		// ���� ��
		next = 0;
		bWariness = false;
		idleRunTime = 0;
		//currPatrol = (currPatrol + 1) % patrolPoints.size();
		return;
	}

	if (next == 0)
	{
		idleRunTime += Time::Delta();
		if (idleRunTime > 1.0f)
		{
			// ��Ʈ�� ����
			next = 1;
		}
	}

	Vector3 position;
	transform->Position(&position);
	Vector3 focus = patrolPoints[currPatrol];
	Vector3 dest = focus - position;
	dest.y = 0.0f;
	float lengthSq = D3DXVec3LengthSq(&dest);

	if (lengthSq < 1.0f)
	{
		next = 0;
		idleRunTime = 0.0f;
		currPatrol = (currPatrol + 1) % patrolPoints.size();
		bWariness = false;
	}
	else
	{
		float speedDelta = 0.0f;
		if (next == 1)
			speedDelta = walkSpeed * Time::Delta();
		else if (next == 2)
			speedDelta = runSpeed * Time::Delta();

		// ����
		Vector3 dest2;
		D3DXVec3Normalize(&dest2, &(dest));
		ratate->SetTarget(dest2);

		Quaternion q;
		transform->Rotation(&q);
		q = ratate->GetRotation(q, -transform->Forward(), speedDelta * turnSpeed);
		transform->Rotation(q);

		position += -transform->Forward() * speedDelta;
		transform->Position(position);
	}


}

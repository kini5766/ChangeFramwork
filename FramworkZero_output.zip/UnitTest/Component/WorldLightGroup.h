#pragma once

class WorldLightGroup
{
public:
	WorldLightGroup();
	~WorldLightGroup();

	void Render();

private:

};